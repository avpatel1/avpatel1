// Jai Shakti Mata
// Remember style matters!

/* // -----------------------
Name: Aryan Patel
SID: 1665166
CCID: avpatel1
CMPUT 275 LBL EB1 Winter 2022

Weekly Exercise 4 - rivers
// ----------------------- */


#include <iostream>
#include <unordered_map>
using namespace std;

int query(int*, int, int, int);

int main() {
/* 
Description: the main function take input from the input file then it finds to which river, 
			 two sub rivers merge or it meets directly to the ocean.
Arguments: the main function takes multiple lines of code, first line has to two inputs number of rivers and 
		   number of queries. Based on total number of rivers, line two have that spaced number of river 
		   branches. Finally, based on the total number of queries, there are that number of lines containing
		   two interger each representing one sub branch of the river. 
Returns: the main function prints 0 if the sub-braches does not merge in between only into the ocean otherwise 
		 it prints number of the branch of the river where both of the sub-branches merges. 
*/
	int num_river; 
	int queries;
	cin >> num_river >> queries;

	int num_rivers = num_river + 1; 
	int rivers[num_rivers] = {0};
	for (int i = 1; i < num_rivers; i++) {
		cin >> rivers[i];
	}
	
	for (int i = 0; i < queries; i++){
		int sub_river_1;
		int sub_river_2;
		cin >> sub_river_1 >> sub_river_2;
		// if one of the sub-branch of the river is 0 means its the ocean itself so the final answer is 0
		if ((sub_river_2 || sub_river_1) == 0)
			cout << 0 << endl;
		// if both sub-branch of the river is same then the final value if the sub-branch itself. 
		else if (sub_river_1 == sub_river_2)
			cout << sub_river_2 << endl;
		else
			cout << query(&rivers[1], num_river, sub_river_1, sub_river_2) << endl;;
	}

	return 0;
}



int query(int* ptr_rivers, int num_river, int sub_river_1, int sub_river_2){
/* 
Description: it finds to which river, two sub rivers merge or it meets directly to the ocean.
Arguments: the query function takes one pointer and three interger values as argument. 
           Pointer refere to the first index of the input array that contains all the river branches.
           One of the three integer represents total number of river and other two represents two sub-braches
           of the river on which the function operates on.
Returns: the query function returns 0 if the sub-braches does not merge in between only into the ocean otherwise 
		 it returns number of the branch of the river where both of the sub-branches merges.
*/


	int num_rivers = num_river + 1; 
	int rivers[num_rivers] = {0};
	for (int i = 1; i < num_rivers; i++) {
		rivers[i] = *(ptr_rivers++);
	}

	// unordered_map is used to whether both sub-branch of the river merges same branch of the river
	unordered_map<int,int> count_table;
	const int count = 1;
	count_table[sub_river_1] = count;
	count_table[sub_river_2] = count;
	int final = 0;

	int a = sub_river_1;
	while (a != 0) {
		int value = rivers[a];
		if (count_table[value] == 0)
			count_table[value] = count;
		else
		{	
			final = value;
			break;
		}
		a = value;
	}

	int b = sub_river_2;
	while (b != 0) {
		int value = rivers[b];
		if (count_table[value] == 0)
			count_table[value] = count;
		else
		{
			final = value;
			break;
		}
		b = value;
	}

	if (final == 0)
		return 0;
	else 
		return final;
}
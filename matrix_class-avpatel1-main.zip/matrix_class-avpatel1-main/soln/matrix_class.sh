#!/bin/bash
make -s && ./we5_solution

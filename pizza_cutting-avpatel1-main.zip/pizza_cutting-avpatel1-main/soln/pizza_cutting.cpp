#include <iostream>
#include <iostream>
#include <cstring>
#include <string>
#include<math.h>
#include<stdio.h>
using namespace std;

int main(){
	
	// declare your variables
	int base;
	int num_slice;	

	// read the input
	cin >> base >> num_slice;

	// solve, good luck!
	if ((num_slice == 1) || (base == num_slice))
		{
			cout << "GOOD" << endl;
			return 0;
		}
	else if (base == 1 )
		{
			cout << "BAD" << endl;
			return 0;
		}
	else if (base > num_slice)
		{
			cout << "BAD" << endl;
			return 0;
		}
	else
	{

		for (int i = 0; i < 21; i++)
		{
			int var = pow(base,i);
			if (var == num_slice)
				{
					cout << "GOOD" << endl;	
					return 0;
				}
		}		
		cout << "BAD" << endl;
		return 0;
	}




	return 0;
}

#!/bin/bash
g++ cake_cutting.cpp -o cake_cutting -Wall && ./cake_cutting
rm -f ./cake_cutting

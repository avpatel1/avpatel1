#!/bin/bash
g++ idols.cpp -o idols -Wall -std=c++11 -g && ./idols
rm -f ./idols

// Remember, style matters!
// While you may rely upon additional functions 
// ensure reverse is declared and functions as described


/* // -----------------------
Name: Aryan Patel
SID: 1665166
CCID: avpatel1
CMPUT 275 LBL EB1 Winter 2022

Weekly Exercise 2 - idols
// ----------------------- */


// the only allowed standard header file 
#include <iostream> // this is the only header you may use (for cin, cout, and endl)

// tell the main function that reverse function exist in this cpp file
void reverse(int*,int*);

// main function that runs all commands
int main() {
  // first input length of array  
  int inte;
  std::cin >> inte;
  // second input elements of array of length inte
  int a[inte];
  for (int i = 0; i < inte; i++)
  	std::cin >> a[i];
  
  // initilize two array of length inte one that take integer as value and second that will take value as pointer that will refere to the main array a 
  int ab[inte] = {0};
  int* abc[inte] = {0};
  // constant b and c that will be helpful in counting full later
  int b = 0;
  int c = 1;
 
  // this two for loop goes over each element of the array a check if it is an idol or not
  // if it is an idol it will store it in array ab and abc as integer and pointer reference respectively
  for (int i = 0; i < inte; i++)
  {
    for (int ii = c; ii < inte; ii++)
    {
      if (a[ii] >= a[i])
      break;
      if (ii == (inte-1))
      {
        ab[b] = a[i];
        abc[b] = &a[i];
        // this if function reverse elements of the main array a if it's a first idol and does not appear as first or second element of the main array
        if (b == 0 && i != 0 && i != 0)
        {
          reverse(&a[0], &a[i-1]);
        }
        b = b + 1;
      }  
    }
    c = c + 1;
  }
  ab[b] = a[inte-1];
  abc[b] = &a[inte-1];

  // this will print out all idols 
  std::cout << ab[0];
  for (int i = 1; i <= b; i++)
  {
    if (ab[i] != 0)
      std::cout << " " << ab[i] ;  
  }
  std::cout << std::endl;
 
  // if only the last element of the main array is idol then this will call the reverse function
  if (b == 0)
  	reverse(&a[0], &a[inte-2]);

  // call reverse function with begining and end values
  for (int i = 0; i < b; i++)
  {
    // if two idols are next to two eachother in the main array a no need to call reverse function
  	if (((abc[i]+1) == abc[i+1]) || ((abc[i]+2) == abc[i+1]))
  		int arr = 0;
  	else
    	reverse(abc[i]+1, abc[i+1]-1);
  }

  // this will print final array with all reverses
  std::cout << a[0];
  for (int i = 1; i < inte; i++)
  	std::cout << " " << a[i];
  std::cout << std::endl;
 
 
  return 0;
}


// reverse function will reverse all values between two points
void reverse(int* begin, int* end)
{
  // finds the length of the elements that need to be reversed
  int diff = (end - begin);
  int dif = diff + 1;
  int arr[dif] = {0};
  arr[0] = *begin;

  // first put all elements that need to be reversed in an array called arr
  for (int i = 1; i <= diff; i++)
  {
    arr[i] = *(++begin);
  }

  // starting pointer was moved to get the values into array arr so move back the pointer to its original position
  for (int i = 0; i < diff; i++)
    *(--begin);   

  // reverse the values using pointer
  *begin = arr[dif-1];
  for (int i = 1; i <= diff; i++)
  {
    *(++begin) = arr[diff-i];
  }
}
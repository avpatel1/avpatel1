/* // -----------------------
Name: Aryan Patel
SID: 1665166
CCID: avpatel1
CMPUT 275 LBL EB1 Winter 2022

Weekly Exercise 3 - sales
// ----------------------- */

// the only allowed standard header file 
#include <iostream>

// main function that runs all commands
int main() {
/* 
Description: this program takes three inputs and the main objective of this program is to find whether sum of coast of any two product in the store sum up to the given price
Arguments: three inputs two intergers total number of iteams and value need to be find and one interger array of length of total number of iteams.
Returns: Prints either YES  or NO based on whether there is any two products whos price sum up to given price or not 
*/
  
  // first input length of array and total price
  int iteams;
  int total_price;
  std::cin >> iteams >> total_price;
  // second input elements of array of length iteams
  int iteam_price[iteams];
  for (int i = 0; i < iteams; i++)
  {
  	std::cin >> iteam_price[i];
  }	

  // initilize constant variables that will used later in the calculation 
  int first = 0;
  int last = iteams - 1;
  int x = 0;

  // while loop will everytime when first is less than last
  while(first < last)
  {	
  	// if the sum of two items equals to total price, x will be equal to 1 and it will break the while loop
  	if ((iteam_price[first] + iteam_price[last]) == total_price)
  	{
  		x = 1;
  		break;
  	}
  	// if the sum of two iteams is less than desired total than one will be added to first as the array is sorted so the next larger value will be at next index
  	else if ((iteam_price[first] + iteam_price[last]) < total_price)
  		first = first + 1; 
  	// if the sum of two iteams is more than desired total than one will be subtracted from last as the array is sorted so the next smalller value will be at next index
  	else
  		last = last - 1;
  }

  if (x == 1 )
  	std::cout << "YES" << std::endl;
  else
  	std::cout << "NO" << std::endl; 
}
#include "ref_manager.h"
#include <assert.h>

/* // ----------------------
Name: Aryan Patel
SID: 1665166
CCID: avpatel1
CMPUT 275 LBL EB1 Winter 2022

Weekly Exercise 3 - reference manager
// ----------------------- */


ReferenceManager::ReferenceManager() {
  numToDelete = 0;
  for (int i = 0; i < MAX_PTRS; i++) {
    pointers[i] = NULL;
  }
  for (int i = 0; i < MAX_GARBAGE; i++) {
    garbage[i] = NULL;
  }
}

ReferenceManager::~ReferenceManager() {
/* 
Description: This will go over all pointers in the pointers array array to reassign pointer to NULL and then calls garbagecollect to free up that space and prints those final left values
Returns: Sets all pointers in teh pointers array to NULL and print and delete whatever those pointers had to it and delete them using garbageCollect
*/
  for (int i = 0; i < MAX_PTRS; i++) 
  {
    reassignPointer(i, NULL);
  }
  garbageCollect();
}

void ReferenceManager::garbageCollect() {
/* 
Description: thsi function goes through all strings in the garbage array, it will first print then and then delete them. 
Returns: it print whatever is in garbage array and then deletes that value and sets the numToDelete count to 0
         this function does not return any value but it deletes any string without pointyer in the heap i.e. useless to free up heap space
*/
  numToDelete = 0;
  for (int i = 0; i < MAX_GARBAGE; i++)
  {
    if (garbage[i] != NULL)
    {
      cout << garbage[i] << endl;
      delete[] garbage[i];
    }
    else
      break;
  }   
}

void ReferenceManager::reassignPointer(unsigned int ptrIndex, const char* newAddr) {
/* 
Description: the pointer at ptrIndex in the pointers array will reference newAdder
Arguments: ptrIndex - a pointer in the pointers array and newAdder - array with input 
Returns: this function does not return value but it will call garbage collect function when the reference count falls to 0 
          i.e. when no pointer is pointing to it but it still exits in the heap which needs to be deleted 
*/
  if (pointers[ptrIndex] == NULL)
  {
    pointers[ptrIndex] = newAddr;
    if (newAddr != NULL)
    {
      bool y_or_n = (refCount.find(newAddr) != refCount.end());
      if (y_or_n == 1)
        refCount[newAddr] = refCount[newAddr] + 1;
      else 
        refCount[newAddr] = 1;
    }
  }
  else 
  {
    refCount[pointers[ptrIndex]] = refCount[pointers[ptrIndex]] - 1;
    if(refCount[pointers[ptrIndex]] == 0)
    {
      garbage[numToDelete] = pointers[ptrIndex];
      numToDelete = numToDelete + 1;
    }
    
    pointers[ptrIndex] = newAddr;
    if (newAddr != NULL)
    {
      bool yy_or_nn = (refCount.find(newAddr) != refCount.end());
      if (yy_or_nn == 1)
        refCount[newAddr] = refCount[newAddr] + 1;
      else 
        refCount[newAddr] = 1;
    }
  }
}

void ReferenceManager::readString(unsigned int ptrIndex, unsigned int length) {
/* 
Description: Allocate space fro string of size length + 1 because in string array has last index for terminating null characters
Arguments: length - length of the given string and ptrIndex - references to the newly allocated string 
Returns: it does not return any value but calls the function reassignPointer with newly allocated string
*/
  char *newAddr = new char[length + 1];
  cin >> newAddr;
  reassignPointer(ptrIndex, newAddr);
}

const char* ReferenceManager::getPtr(unsigned int ptrIndex) {
  assert(ptrIndex < MAX_PTRS);
  return pointers[ptrIndex];
}

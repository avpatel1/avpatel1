make -s && ./we3_solution

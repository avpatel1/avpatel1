#!/bin/bash
g++ twin_primes.cpp -o twin_primes -Wall && ./twin_primes
rm -f ./twin_primes

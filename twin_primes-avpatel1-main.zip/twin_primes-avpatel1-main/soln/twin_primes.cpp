// Remember, style matters!
// While you may rely upon additional functions 
// ensure isPrime and twinPrime follow the specifications.

/* // -----------------------
Name: Aryan Patel
Student ID: 1665166
CMPUT 275 LBL EB1

Weekly Exercise 1 - twin_primes 
// ----------------------- */


#include <iostream>
#include <iostream>
#include <cstring>
#include <string>
#include<math.h>
#include<stdio.h>
using namespace std;

bool isPrime(int); 
void twinPrime(int);

int main ()
{
	char p_or_t;
	int integer_num;	

	cin >> p_or_t >> integer_num;
	
	if (p_or_t == 'p')
	{
		int t_or_f = isPrime (integer_num);
		if (t_or_f == 1)
		{
			cout << "prime" << endl;
		}
		else
		{
			cout << "not prime" << endl;
		}

	}
	else
	{
		twinPrime (integer_num);
	}

	return 0;
}


bool isPrime(int n)
{
	if (n <= 1)
	{
		return false;
	}
	else if (n == 2)
	{
		return true;
	}
	else
	{
		for (int i = 2; i < n; i++)
		{
			if (n % i == 0)
			{
				return false;
			}
			else 
			{
				return true; 
			}
		}
	}

}


void twinPrime(int k)
{ 
	int b = 2;
	bool prime = false;

	for (int a = 1; a <= k; a++)
	{
		for (int i = b; i <= 80000; i++)
		{
			for (int ii = 2; ii < i; ii++)
			{
				if (i % ii == 0)
				{
					prime = false;
					break;
				}
				else 
				{
					prime = true;
				}
			}
			if (prime == 1)
			{
				int sp = i + 2;
				bool sprime = false;
				for (int secp = 2; secp < sp; secp++)
				{
					if (sp % secp == 0)
					{
						sprime = false;
						break;
					}
					else
					{
						sprime = true;
					}
				}
				if (sprime == 1)
				{
					b = i + 1;
					cout << i << " " << i+2 << endl;
					break;
				}
			}
		}
	}
}
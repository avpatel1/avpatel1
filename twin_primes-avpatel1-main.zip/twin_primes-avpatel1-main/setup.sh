cd test-cases/*
mkdir -p Outputs
mkdir -p Resources
mkdir -p Errors
